# Swift-Tutorial-Metronome

Originally created as an answer to: https://stackoverflow.com/questions/51402112/metronome-ios-swift-beat-visuals-lag/51402453?noredirect=1#51402112

Use as you see fit.
