# Metronome Idea
IOS Metronome Idea based on AVAudioEngine (Swift)

An Idea of how to make an accurate metronome on Swift using AVAudioEngine

This one is based on the sample rate - not on some kind of timer
